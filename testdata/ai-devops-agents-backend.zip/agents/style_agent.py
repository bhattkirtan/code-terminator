# Applies SCSS styles from uploaded file or theme image
def apply_styles(theme_reference):
    return ":root { --primary-color: #1e90ff; }"
